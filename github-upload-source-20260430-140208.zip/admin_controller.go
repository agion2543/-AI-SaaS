package controller

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"

	"go-web-gin-health/internal/dto"
	"go-web-gin-health/internal/repository"
	"go-web-gin-health/internal/service"
	"go-web-gin-health/internal/utils"
)

type AdminController struct {
	admin     *service.AdminService
	dashboard *service.DashboardService
	audit     *service.AuditService
}

func NewAdminController(admin *service.AdminService, dashboard *service.DashboardService, audit *service.AuditService) *AdminController {
	return &AdminController{admin: admin, dashboard: dashboard, audit: audit}
}

func (ctl *AdminController) Dashboard(c *gin.Context) {
	data, err := ctl.dashboard.SummaryWithRange(c.Query("start_date"), c.Query("end_date"))
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	utils.Success(c, data)
}

func (ctl *AdminController) AuditLogs(c *gin.Context) {
	page, pageSize := utils.NormalizePage(atoi(c.Query("page")), atoi(c.Query("page_size")))
	logs, total, err := ctl.audit.List(service.AuditListFilter{
		Action:     c.Query("action"),
		ActorType:  c.Query("actor_type"),
		TargetType: c.Query("target_type"),
		Keyword:    c.Query("keyword"),
		MerchantID: uint(atoi(c.Query("merchant_id"))),
	}, page, pageSize)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	utils.Success(c, gin.H{"list": logs, "total": total})
}

func (ctl *AdminController) Users(c *gin.Context) {
	page, pageSize := utils.NormalizePage(atoi(c.Query("page")), atoi(c.Query("page_size")))
	users, total, err := ctl.admin.ListUsersFiltered(page, pageSize, repository.UserListFilter{
		Keyword:     c.Query("keyword"),
		MemberLevel: c.Query("member_level"),
		Status:      c.Query("status"),
		Role:        c.Query("role"),
		SortBy:      c.Query("sort_by"),
		SortOrder:   c.Query("sort_order"),
	})
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	utils.Success(c, gin.H{"list": users, "total": total})
}

func (ctl *AdminController) Customers(c *gin.Context) {
	page, pageSize := utils.NormalizePage(atoi(c.Query("page")), atoi(c.Query("page_size")))
	customers, total, err := ctl.admin.ListCustomerProfiles(page, pageSize, service.CustomerProfileFilter{
		Keyword:   c.Query("keyword"),
		AITag:     c.Query("ai_tag"),
		Status:    c.Query("status"),
		SortBy:    c.Query("sort_by"),
		SortOrder: c.Query("sort_order"),
	})
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	utils.Success(c, gin.H{"list": customers, "total": total})
}

func (ctl *AdminController) Merchants(c *gin.Context) {
	page, pageSize := utils.NormalizePage(atoi(c.Query("page")), atoi(c.Query("page_size")))
	merchants, total, err := ctl.admin.ListMerchants(page, pageSize)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	utils.Success(c, gin.H{"list": merchants, "total": total})
}

func (ctl *AdminController) MerchantPlans(c *gin.Context) {
	plans, err := ctl.admin.ListMerchantPlans()
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	utils.Success(c, plans)
}

func (ctl *AdminController) SaveMerchantPlan(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	var req dto.SaveMerchantPlanRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	plan, err := ctl.admin.SaveMerchantPlan(id, req)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, gin.H{"plan": plan})
}

func (ctl *AdminController) MerchantDetail(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	merchant, err := ctl.admin.GetMerchant(id)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, merchant)
}

func (ctl *AdminController) MerchantSubscriptionOrders(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	orders, err := ctl.admin.ListMerchantSubscriptionOrders(id)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, gin.H{"list": orders})
}

func (ctl *AdminController) MerchantStoreOrders(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	orders, err := ctl.admin.ListMerchantStoreOrders(id, atoi(c.DefaultQuery("limit", "10")))
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, gin.H{"list": orders})
}

func (ctl *AdminController) MerchantStores(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	page, pageSize := utils.NormalizePage(atoi(c.Query("page")), atoi(c.Query("page_size")))
	stores, total, err := ctl.admin.ListMerchantStores(id, page, pageSize)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, gin.H{"list": stores, "total": total})
}

func (ctl *AdminController) CreateMerchantStore(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	var req dto.AdminSaveStoreRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	store, err := ctl.admin.SaveMerchantStore(id, 0, req)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, store)
}

func (ctl *AdminController) UpdateMerchantStore(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	storeID := uint(atoi(c.Param("store_id")))
	var req dto.AdminSaveStoreRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	store, err := ctl.admin.SaveMerchantStore(id, storeID, req)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, store)
}

func (ctl *AdminController) DisableMerchantStore(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	storeID := uint(atoi(c.Param("store_id")))
	if err := ctl.admin.DisableMerchantStore(id, storeID); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, gin.H{"updated": true})
}

func (ctl *AdminController) MerchantLeads(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	page, pageSize := utils.NormalizePage(atoi(c.Query("page")), atoi(c.Query("page_size")))
	leads, total, err := ctl.admin.ListMerchantLeads(id, page, pageSize)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, gin.H{"list": leads, "total": total})
}

func (ctl *AdminController) MerchantLeadStats(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	stats, err := ctl.admin.MerchantLeadStats(id)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, stats)
}

func (ctl *AdminController) MerchantAIInsights(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	data, err := ctl.admin.GenerateMerchantInsights(id)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, data)
}

func (ctl *AdminController) UpdateMerchantLead(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	leadID := uint(atoi(c.Param("lead_id")))
	var req dto.UpdateCustomerLeadRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	lead, err := ctl.admin.UpdateMerchantLead(id, leadID, req)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, gin.H{"lead": lead, "updated": true})
}

func (ctl *AdminController) UpdateMerchantStatus(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	var req dto.UpdateMerchantStatusRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	if err := ctl.admin.UpdateMerchantStatus(id, req.Status); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	merchant, _ := ctl.admin.GetMerchant(id)
	targetName := ""
	if merchant != nil {
		targetName = merchant.Name
	}
	ctl.audit.Record(c, service.AuditRecordInput{
		Action:     "merchant_status_update",
		TargetType: "merchant",
		TargetID:   id,
		TargetName: targetName,
		MerchantID: &id,
		Detail:     gin.H{"status": req.Status},
	})
	utils.Success(c, gin.H{"updated": true})
}

func (ctl *AdminController) OpenMerchantSubscription(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	var req dto.OpenMerchantSubscriptionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	merchant, err := ctl.admin.OpenMerchantSubscription(id, req)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	ctl.audit.Record(c, service.AuditRecordInput{
		Action:     "merchant_subscription_open",
		TargetType: "merchant",
		TargetID:   id,
		TargetName: merchant.Name,
		MerchantID: &id,
		Detail: gin.H{
			"plan":          req.Plan,
			"duration_days": req.DurationDays,
			"note":          req.Note,
			"expire_at":     merchant.SubscriptionExpireAt,
		},
	})
	utils.Success(c, gin.H{"merchant": merchant})
}

func (ctl *AdminController) StopMerchantSubscription(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	merchant, err := ctl.admin.StopMerchantSubscription(id)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	ctl.audit.Record(c, service.AuditRecordInput{
		Action:     "merchant_subscription_stop",
		TargetType: "merchant",
		TargetID:   id,
		TargetName: merchant.Name,
		MerchantID: &id,
	})
	utils.Success(c, gin.H{"merchant": merchant})
}

func (ctl *AdminController) UpdateUserStatus(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	var req dto.UpdateUserStatusRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	if err := ctl.admin.UpdateUserStatus(id, req.Status); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	ctl.audit.Record(c, service.AuditRecordInput{
		Action:     "user_status_update",
		TargetType: "user",
		TargetID:   id,
		Detail:     gin.H{"status": req.Status},
	})
	utils.Success(c, gin.H{"updated": true})
}

func (ctl *AdminController) ManualOpenMember(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	var req dto.ManualOpenMemberRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	user, err := ctl.admin.AdjustUserMember(id, req)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	ctl.audit.Record(c, service.AuditRecordInput{
		Action:     "user_member_adjust",
		TargetType: "user",
		TargetID:   id,
		TargetName: user.DisplayName,
		Detail: gin.H{
			"package_id":    req.PackageID,
			"member_level":  req.MemberLevel,
			"duration_days": req.DurationDays,
			"expired_at":    req.ExpiredAt,
			"quota_delta":   req.QuotaDelta,
			"auto_renew":    req.AutoRenew,
		},
	})
	utils.Success(c, gin.H{"updated": true, "user": user})
}

func (ctl *AdminController) UpdateUserPhone(c *gin.Context) {
	id := uint(atoi(c.Param("id")))
	var req dto.UpdateUserPhoneRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	if err := ctl.admin.UpdateUserPhone(id, req.Phone); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, gin.H{"updated": true})
}

func (ctl *AdminController) GenerateCards(c *gin.Context) {
	var req dto.BatchCardRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	cards, err := ctl.admin.GenerateCards(req)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, cards)
}

func (ctl *AdminController) Cards(c *gin.Context) {
	list, err := ctl.admin.ListCards()
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	utils.Success(c, list)
}

func (ctl *AdminController) SaveConfigs(c *gin.Context) {
	var req dto.SaveSystemConfigRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	if err := ctl.admin.SaveSystemConfig(req); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, gin.H{"saved": true})
}

func (ctl *AdminController) Configs(c *gin.Context) {
	list, err := ctl.admin.ListSystemConfigs()
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	utils.Success(c, list)
}

func atoi(v string) int {
	value, _ := strconv.Atoi(v)
	return value
}
